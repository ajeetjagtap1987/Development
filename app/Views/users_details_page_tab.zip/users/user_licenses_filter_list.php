
<?php 
use App\Models\CommonModel;
$CommonModel = new CommonModel();
        if(count( $paginateData ) > 0 ) {
            echo '<div class="table-responsive">';
            echo "<table id='zero_config' class='table table-striped '>
                                <thead>
                                    <tr>
                                          <th>Id</th>
                                          <th>Category</th>
                                          <th>Software Name</th>
                                          <th>Created Date</th>
                                          <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody class='refresh_table'>";
            foreach( $paginateData as $user_licenses ){
                $encrypter = \Config\Services::encrypter();
                $e_id=bin2hex($encrypter->encrypt($user_licenses['id']));
                $convert_time = $CommonModel->converToTz($user_licenses['created_date']);
                $category =  $CommonModel->getDataById($table_name='category',$user_licenses['category_id']);
                $category_name= count($category)>0 ? $category[0]['category_name'] : '';
                echo "<tr>";
                echo "<td>".$user_licenses['id']."</td>";
                echo "<td>".$category_name."</td>";
                echo "<td>".$user_licenses['software_name']."</td>";
                // if($user_licenses['status'] == ACTIVE){
                //     echo "<td>Active</td>";
                // }else{
                //     echo "<td>Inactive</td>";
                // }
                echo "<td nowrap>".$convert_time."</td>";
                echo "<td nowrap>";
               // echo "<a href='".base_url()."/user_licenses/edit/".$e_id."' class='btn btn-icon btn-sm btn-primary' title='Edit'><i class='ti ti-edit'></i></a>";
                echo "</td>";
                echo"</tr>";
            }
            echo "</tbody></table>";
            echo '</div>';
            // echo '<div class="card-footer d-flex align-items-center">';
            // echo $pager->links('default', 'boostrap_pagination');
            // echo '</div>';
        } else {
            echo '<div class="shadow-none p-3 mb-5 bg-light rounded text-center"><h4 class="text-center" style="margin: revert;">Data Not Found</h4></div>';   
        }
?>