<?php
$encrypter = \Config\Services::encrypter();
$u_id=bin2hex($encrypter->encrypt($user[0]['id']));
?>
	<div class="container-xl">
          <!-- Page title -->
       	<div class="page-header d-print-none">
          <?php echo @view('includes/breadcrumb2', ['level_1' => 'User List', 'level_1_url' => 'users/list', 'level_2' => 'User Edit']); ?>
        </div>
        <div class="page-body">
	        <div class="container-xl">
	            <div class="row row-cards">
	              	<div class="col-12">
								    <?php
							      if(session()->has("error")){
							      ?>
							        <div class="alert alert-danger alert-dismissible">
							          <?php echo session("error"); ?>
							        </div>  
							      <?php
							      }
							      ?>
							      <?php
							      if(session()->has("success")){
							      ?>
							        <div class="alert alert-success alert-dismissible">
							          <?php echo session("success"); ?>
							        </div>  
							      <?php
							      }
							      ?>
		              	<div class="card">
			                <div class="card-body">
			                	<form action="<?= base_url();?>/users/user-update/<?= $u_id?>" id="update" method="post" autocomplete="off">
			                    <div class="form-group mb-3 ">
			                      <label class="form-label required">First Name</label>
			                      <div >
			                        <input type="text" name="first_name" class="form-control" placeholder="Enter First Name" value="<?= $user[0]['first_name']?>" required><!-- 
			                        <small class="form-hint">We'll never share your email with anyone else.</small> -->
			                      </div>
			                    </div>
			                    <div class="form-group mb-3 ">
			                      <label class="form-label required">Last Name</label>
			                      <div >
			                        <input type="text" name="last_name" class="form-control" placeholder="Enter Last Name" value="<?= $user[0]['last_name']?>" required>
			                      </div>
			                    </div>
			                    <div class="form-group mb-3 ">
			                      <label class="form-label required">Email Address</label>
			                      <div >
			                        <input type="email" class="form-control" aria-describedby="emailHelp" placeholder="Enter email" value="<?= $user[0]['email']?>" disabled>
			                      </div>
			                    </div>
			                    <div class="form-group mb-3 ">
			                      <label class="form-label required">Job Title</label>
			                      <div >
			                        <input type="text" name="job_title" class="form-control" placeholder="Enter Job Title" value="<?= $user[0]['job_title']?>" required>
			                      </div>
			                    </div>
			                    <div class="form-group mb-3 ">
			                      <label class="form-label">Reporting Head</label>
			                      <div>
			                        <input type="text" name="reporting_head" class="form-control" placeholder="Enter Reporting Head"  value="<?= $user[0]['reporting_head']?>">
			                      </div>
			                    </div>
			                    <div class="form-group mb-3 ">
			                      <label class="form-label">User Work Location</label>
			                      <div>
			                        <select class="form-select" name="user_work_location"  required>
			                        	<option value="">Select</option>
			                        	<option value="<?php echo WORK_LOCATION_OFFICE ?>" <?= $user[0]['user_work_location'] == WORK_LOCATION_OFFICE ? 'selected':'' ?>>Office</option>
			                        	<option value="<?php echo WORK_LOCATION_HOME ?>" <?= $user[0]['user_work_location'] == WORK_LOCATION_HOME ? 'selected':'' ?>>Home</option>
			                        </select>	
			                      </div>
			                    </div>
			                    <div class="form-group mb-3 ">
			                      <label class="form-label required">Joining Date</label>
			                      <div class="input-icon mb-2">
																<input class="form-control datepicker" name="joining_date" placeholder="Select Joining Date" value="<?= $user[0]['joining_date']?>" required>
																<span class="input-icon-addon">
																<i class="ti ti-calendar"></i>
																</span>
														</div>
			                    </div>
			                    <div class="form-footer">
					                <button type="submit" class="btn btn-primary submit_button" onclick="return confirm('Are you sure?');">Update</button>
		                            <button class="btn btn-primary loader_button" type="button" disabled>
		                              <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
		                              Loading...
		                            </button>
			                    </div>
			                  </form>
			                </div>
		                </div>
	            	</div>
	          	</div>
	        </div>
        </div>
  </div>      
<script type="text/javascript">
  	$("#update").submit(function(event){
      event.preventDefault();
      var post_url = $(this).attr("action");
      var request_method = $(this).attr("method");
      var form_data = new FormData(this);
        $('.submit_button').css('display','none');
        $('.loader_button').css('display','block');
        $.ajax({
          url : post_url,
          type: request_method,
          data : form_data,
          dataType: 'json',
          contentType: false,
          cache: false,
          processData:false
        }).done(function(response){ 
            if(response.status == 'success' ){
              // Swal.fire({
              //   icon: response.status,
              //   text: response.message,
              // });
              window.location.href = '<?php echo base_url()?>/users/list';
            }else{
              Swal.fire({
                icon: response.status,
                text: response.message,
              })
            } 
            $('.submit_button').css('display','block');
            $('.loader_button').css('display','none');
            
        });
     
  	});
</script>