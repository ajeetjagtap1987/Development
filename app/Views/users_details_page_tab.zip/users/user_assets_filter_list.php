
<?php 
use App\Models\CommonModel;
$CommonModel = new CommonModel();
        if(count( $paginateData ) > 0 ) {
            echo '<div class="table-responsive">';
            echo "<table id='zero_config' class='table table-striped '>
                                <thead>
                                    <tr>
                                          <th>Id</th>
                                          <th>Category Name</th>
                                          <th>Asset Id</th>
                                          <th>Model Name</th>
                                          <th>Serial No</th>
                                          <th>Warranty Expiry Date</th>
                                          <th>Created Date</th>
                                          <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody class='refresh_table'>";
            foreach( $paginateData as $user_asset ){
                $encrypter = \Config\Services::encrypter();
                $e_a_id=bin2hex($encrypter->encrypt($user_asset['a_id']));
                $convert_time = $CommonModel->converToTz($user_asset['created_date']);
                $category =  $CommonModel->getDataById($table_name='category',$user_asset['category_id']);
                $category_name= count($category)>0 ? $category[0]['category_name'] : '';
                echo "<tr>";
                echo "<td>".$user_asset['id']."</td>";
                echo "<td>".$category_name."</td>";
                echo "<td><a href='".base_url()."/assets/view/".$e_a_id."' target='_blank' title='View'>".$user_asset['a_asset_id']."</a></td>";
                echo "<td>".$user_asset['model_name']."</td>";
                echo "<td>".$user_asset['serial_no']."</td>";
                echo "<td>".$user_asset['warranty_expiry_date']."</td>";
                // if($user_asset['status'] == ACTIVE){
                //     echo "<td>Active</td>";
                // }else{
                //     echo "<td>Inactive</td>";
                // }
                echo "<td nowrap>".$convert_time."</td>";
                echo "<td nowrap>";
               echo "<button class='btn btn-icon btn-sm btn-danger' title='Edit' onclick='revokeAssets(".$user_asset['id'].")'><i class='ti ti-arrow-back-up'></i></button>";
                echo "</td>";
                echo"</tr>";
            }
            echo "</tbody></table>";
            echo '</div>';
            // echo '<div class="card-footer d-flex align-items-center">';
            // echo $pager->links('default', 'boostrap_pagination');
            // echo '</div>';
        } else {
            echo '<div class="shadow-none p-3 mb-5 bg-light rounded text-center"><h4 class="text-center" style="margin: revert;">Data Not Found</h4></div>';   
        }
?>