
<?php 
use App\Models\CommonModel;
$CommonModel = new CommonModel();
        if(count( $paginateData ) > 0 ) {
            echo '<div class="table-responsive">';
            echo "<table id='zero_config' class='table table-striped '>
                                <thead>
                                    <tr>
                                          <th>Id</th>
                                          <th>Name</th>
                                          <th>Email</th>
                                          <th>Job Title</th>
                                          <th>User Type</th>
                                          <th>Status</th>
                                          <th>Created Date</th>
                                          <th width='120px'>Action</th>
                                    </tr>
                                </thead>
                                <tbody class='refresh_table'>";
            foreach( $paginateData as $user ){
                $encrypter = \Config\Services::encrypter();
                $u_id=bin2hex($encrypter->encrypt($user['id']));
                $convert_time = $CommonModel->converToTz($user['created_date']);
                echo "<tr>";
                echo "<td>".$user['id']."</td>";
                echo "<td><a href='".base_url()."/users/details/".$u_id."'title='Detail'>".$user['first_name']." ".$user['last_name']."</a></td>";
                echo "<td>".$user['email']."</td>";
                echo "<td>".$user['job_title']."</td>";
                echo "<td>";
                foreach (USER_TYPE as $key => $value) {
                    if($user['user_type'] == $key){
                         echo $value;
                    }
                }
                echo "</td>";
                if($user['status'] == ACTIVE){
                    echo "<td>Active</td>";
                }else{
                    echo "<td>Inactive</td>";
                }
                echo "<td nowrap>".$convert_time."</td>";
                echo "<td nowrap>";
                if(session('user_type') == ADMIN){
                    if($user['user_type'] != ADMIN){
                        if($user['status'] == ACTIVE){
                        echo "<a href='".base_url()."/users/edit/".$u_id."' class='btn btn-icon btn-sm btn-primary' title='Edit'><i class='ti ti-edit'></i></a>";
                        echo "<a href='".base_url()."/users/change-password/".$u_id."' class='btn btn-icon btn-sm btn-warning' title='Change Password' ><i class='ti ti-key'></i></a>";
                        ?>
                        <a href="<?php echo base_url()."/users/status-change/".INACTIVE."/".$u_id?>" class="btn btn-icon btn-sm btn-danger" title="In Active" onclick="return confirm('Are you sure?');"><i class='ti ti-user-off'></i></a>
                <?php   }
                    }
                }elseif(session('user_type') == TECHNICIAN){
                    if($user['status'] == ACTIVE){
                        echo "<a href='".base_url()."/users/edit/".$u_id."' class='btn btn-icon btn-sm btn-primary' title='Edit'><i class='ti ti-edit'></i></a>";
                    ?>
                        <a href="<?php echo base_url()."/users/status-change/".INACTIVE."/".$u_id?>" class="btn btn-icon btn-sm btn-danger" title="In Active" onclick="return confirm('Are you sure?');"><i class='ti ti-user-off'></i></a>
                    <?php
                    }    
                    
                }
                echo "</td>";
                echo"</tr>";
            }
            echo "</tbody></table>";
            echo '</div>';
            echo '<div class="card-footer d-flex align-items-center">';
            echo $pager->links('default', 'boostrap_pagination');
            echo '</div>';
        } else {
            echo '<div class="shadow-none p-3 mb-5 bg-light rounded text-center"><h4 class="text-center" style="margin: revert;">Data Not Found</h4></div>';   
        }
?>