	<div class="border-bottom py-2">
        <div class="d-flex">
          <div class="text-muted">
          </div>
          <div class="ms-auto text-muted">
          	<div class="ms-2 d-inline-block">
            	<button class="btn btn-icon btn-primary" data-bs-toggle="modal" data-bs-target="#licenses_assets_model" style="margin: 0px 0px 0px 8px;"><i class="ti ti-plus"></i>Assign Licenses&nbsp;</button>
            </div>
            <div class="ms-2 d-inline-block">
                <div class="input-icon">
                    <input type="text" value="" id="licenses_keyword" class="form-control" placeholder="Search…">
                    <span class="input-icon-addon"><i class='ti ti-search'></i></span>
                </div>
            </div>
          </div>
          <div class="text-muted">
           		<button class="btn btn-icon btn-primary licenses_clear_filter" style="margin: 0px 0px 0px 8px;"><i class="ti ti-refresh"></i></button>
          </div>
        </div>
  	</div>
  	<div class="overlay-wrapper">
		<div class="overlay loader"><i class="fas fa-3x fa-sync-alt fa-spin"></i>
		</div>
		<div class="licenses_filter_data" >
		</div>
	</div>

  <div class="modal modal-blur fade" id="licenses_assets_model" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Assign License</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="<?php echo base_url();?>/users-licenses/assign/<?php echo $u_id;?>" method="post" id="assign_license" autocomplete="off">
        <div class="modal-body">
        	<div class="form-group col-md-12 mb-3 ">
              <label class="form-label required">Software Name</label>
              <div>
  							<select class="license_name form-select" id="license_name" name="license_id" data-live-search="true" style="width: 100%; height:36px;display: initial;" required="true"></select>
              </div>
            </div>
            <div class="form-group col-md-12 mb-3 asset_info">
            </div>		
        </div>
        <div class="modal-footer">
          <button type="button" class="btn me-auto" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary submit_button" onclick="return confirm('Are you sure?');">Submit</button>
          <button class="btn btn-primary loader_button" type="button" disabled>
            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            Loading...
          </button>
        </div>
        </form>
      </div>
    </div>
  </div>
<script type="text/javascript">
	$('.license_name').select2({
			dropdownParent: $('#licenses_assets_model'),
      placeholder: 'Search and Select Software',
      ajax: {
        url: '<?php echo base_url() ?>/licenses/autocomplete',
        dataType: 'json',
        method:'GET',
        delay: 250,
        data: function (data) {
          return {
                  searchTerm: data.term // search term
                };
              },
              processResults: function (response) {
                return {
                  results:response
                };
              },
              cache: true
            }
    });
	$(document).ready(function(){
        licenses_filter_data(1);
    });
    //Licenses list filter
    $('.licenses_clear_filter').click(function() {
        window.location.href = '<?php echo base_url()?>/users/details/<?php echo $u_id;?>'+'#val_licenses';
    });
    $('#licenses_keyword').keyup(function(){
        if( this.value.length < 4 ) return;
        licenses_filter_data(1);
    });
    function licenses_filter_data(page)
    {
        $('.loader').css('display','flex');
        var show_per_page = $('.licenses_show_per_page').val();
        var user_id = '<?php echo $user[0]['id'];?>';
        var keyword       = $('#licenses_keyword').val().trim();
        $.ajax({
            url:"<?php echo base_url() ?>/users-licenses/filter/"+page,
            method:"POST",
            data:{user_id:user_id, show_per_page:show_per_page, keyword:keyword},
            success:function(data)
            {
                $('.loader').css('display','none');
                $('.licenses_filter_data').html(data);
            }
        })
    }
  	// $(document).ready(function (){
    // $(".license_name").change(function (){  
    //     var license_name = $('.license_name').val();
    //     var data = dataType ='';
    //     var success = true;
    //     $('.asset_info').html('');
    //     $.ajax({
    //           type: "GET",
    //           url: "<?php echo base_url();?>/get-assets-by-id/"+license_name,
    //           data: {},
    //           dataType:'json',
    //           success: function(data) 
    //               {
    //                 if(data.status == 'success'){
    //                   $('.asset_info').html(data.asset_info);
    //                 }
    //               }
    //           });
    // });
    // });
  	$("#assign_license").submit(function(event){
      event.preventDefault();
      var post_url = $(this).attr("action");
      var request_method = $(this).attr("method");
      var form_data = new FormData(this);
        $('.submit_button').css('display','none');
        $('.loader_button').css('display','block');
        $.ajax({
          url : post_url,
          type: request_method,
          data : form_data,
          dataType: 'json',
          contentType: false,
          cache: false,
          processData:false
        }).done(function(response){ 
            if(response.status == 'success' ){
              window.location.href = '<?php echo base_url()?>/users/details/<?php echo $u_id;?>'+'#val_licenses';
            }else{
              Swal.fire({
                icon: response.status,
                text: response.message,
              })
            } 
            $('.submit_button').css('display','block');
            $('.loader_button').css('display','none');
            
        });
     
  });
</script>    